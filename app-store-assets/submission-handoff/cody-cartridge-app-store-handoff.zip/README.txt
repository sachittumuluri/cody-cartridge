Cody Cartridge App Store Handoff

This archive contains generated App Store Connect copy, review notes, screenshots, policy/support drafts, release evidence, and the public-site archive.
It also includes RELEASE_MACHINE_REPORT.md as the redacted gate snapshot to inspect before using Apple signing or upload credentials.

Support URL: TODO_PUBLIC_SITE_URL/support.html
Privacy Policy URL: TODO_PUBLIC_SITE_URL/privacy.html
Current blocker count: 17

MAS submission posture:
- Bundle: dist/mas-arm64/Cody Cartridge.app
- Mode: local-rehearsal-only
- Submission ready: no
- Embedded provisioning profile: missing
- Code signature: not verified
- Signed upload packages: 0/0
- Signed current-version upload packages: 0/0
- Readiness note: not submission-ready until the release machine produces a signed MAS app with embedded provisioning profile and a signed current-version upload .pkg

Release-machine order:
1. Review PUBLIC_RELEASE_INPUTS.md, then fill app-store-assets/site.env or export the CODY_* public URL/contact values.
2. Run npm run site:store && npm run site:archive && npm run publish-packet:store && npm run public-host:store; the public-site archive includes _headers and vercel.json static-host metadata.
3. Run npm run export-compliance:store && npm run packet:store && npm run review-brief:store && npm run copy-map:store && npm run check:store-version && npm run check:export-compliance && npm run check:store-copy && npm run check:artifact-privacy.
4. Run npm run check:store-urls -- --strict and npm run check:published-site -- --strict after publishing the public site.
5. Open RELEASE_OPERATOR_QUEUE.md, RELEASE_DASHBOARD.html, and RELEASE_MACHINE_REPORT.md, review RELEASE_RESOLUTION_PLAN.md, SIGNING_ASSET_REPORT.md, UPLOAD_COMMAND_PACKET.md, SIGNING_UPLOAD_RUNBOOK.md, and FINAL_SUBMISSION_CHECKLIST.md, install Apple signing/provisioning assets, then run npm run release:store:preflight.

The handoff archive intentionally excludes app-store-assets/site.env, raw upload delivery logs, dist/, node_modules/, local music files, YouTube Music Takeout exports, Apple signing certificates/private keys, provisioning profiles, and App Store Connect API credentials.
